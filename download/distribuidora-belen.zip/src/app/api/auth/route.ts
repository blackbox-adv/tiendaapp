import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

export async function POST(request: Request) {
  try {
    const { email, password } = await request.json()

    const admin = await db.adminUser.findUnique({ where: { email } })

    if (!admin || admin.password !== password) {
      return NextResponse.json({ error: 'Credenciales inválidas' }, { status: 401 })
    }

    return NextResponse.json({
      id: admin.id,
      email: admin.email,
      name: admin.name,
    })
  } catch (error) {
    return NextResponse.json({ error: 'Error en login' }, { status: 500 })
  }
}
