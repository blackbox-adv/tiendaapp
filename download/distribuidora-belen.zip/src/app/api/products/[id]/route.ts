import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const product = await db.product.findUnique({
      where: { id },
      include: {
        category: true,
        images: { orderBy: { order: 'asc' } },
        mattress: {
          include: { images: { orderBy: { order: 'asc' } }, category: true }
        },
        beds: {
          include: { category: true, images: { orderBy: { order: 'asc' }, take: 1 } }
        },
      },
    })

    if (!product) {
      return NextResponse.json({ error: 'Product not found' }, { status: 404 })
    }

    return NextResponse.json(product)
  } catch (error) {
    return NextResponse.json({ error: 'Error fetching product' }, { status: 500 })
  }
}

export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const body = await request.json()

    // Delete old images if new ones provided
    if (body.images && body.images.length > 0) {
      await db.productImage.deleteMany({ where: { productId: id } })
    }

    const product = await db.product.update({
      where: { id },
      data: {
        name: body.name,
        description: body.description,
        price: parseFloat(body.price),
        originalPrice: body.originalPrice ? parseFloat(body.originalPrice) : null,
        categoryId: body.categoryId,
        isActive: body.isActive !== undefined ? body.isActive : undefined,
        isFeatured: body.isFeatured !== undefined ? body.isFeatured : undefined,
        dimensions: body.dimensions || null,
        material: body.material || null,
        mattressId: body.mattressId || null,
        ...(body.images && body.images.length > 0 ? {
          images: {
            create: body.images.map((img: { url: string; alt?: string; isPrimary?: boolean }, idx: number) => ({
              url: img.url,
              alt: img.alt || body.name,
              order: idx,
              isPrimary: img.isPrimary || idx === 0,
            })),
          },
        } : {}),
      },
      include: {
        category: true,
        images: { orderBy: { order: 'asc' } },
      },
    })

    return NextResponse.json(product)
  } catch (error) {
    return NextResponse.json({ error: 'Error updating product' }, { status: 500 })
  }
}

export async function DELETE(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    await db.productImage.deleteMany({ where: { productId: id } })
    await db.product.updateMany({ where: { mattressId: id }, data: { mattressId: null } })
    await db.product.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error) {
    return NextResponse.json({ error: 'Error deleting product' }, { status: 500 })
  }
}
