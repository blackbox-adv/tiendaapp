import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get('category')
    const search = searchParams.get('search')
    const featured = searchParams.get('featured')

    const where: Record<string, unknown> = { isActive: true }

    if (category && category !== 'todos') {
      where.category = { slug: category }
    }

    if (search) {
      where.name = { contains: search }
    }

    if (featured === 'true') {
      where.isFeatured = true
    }

    const products = await db.product.findMany({
      where,
      include: {
        category: true,
        images: { orderBy: { order: 'asc' } },
        mattress: {
          include: { images: { orderBy: { order: 'asc' }, take: 1 } }
        },
      },
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json(products)
  } catch (error) {
    return NextResponse.json({ error: 'Error fetching products' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    const product = await db.product.create({
      data: {
        name: body.name,
        slug: body.name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '') + '-' + Date.now(),
        description: body.description,
        price: parseFloat(body.price),
        originalPrice: body.originalPrice ? parseFloat(body.originalPrice) : null,
        categoryId: body.categoryId,
        isActive: body.isActive !== undefined ? body.isActive : true,
        isFeatured: body.isFeatured || false,
        dimensions: body.dimensions || null,
        material: body.material || null,
        mattressId: body.mattressId || null,
        images: {
          create: (body.images || []).map((img: { url: string; alt?: string; isPrimary?: boolean }, idx: number) => ({
            url: img.url,
            alt: img.alt || body.name,
            order: idx,
            isPrimary: img.isPrimary || idx === 0,
          })),
        },
      },
      include: {
        category: true,
        images: { orderBy: { order: 'asc' } },
      },
    })

    return NextResponse.json(product, { status: 201 })
  } catch (error) {
    return NextResponse.json({ error: 'Error creating product' }, { status: 500 })
  }
}
