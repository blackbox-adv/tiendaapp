import { NextResponse } from 'next/server'
import { writeFile, mkdir } from 'fs/promises'
import path from 'path'
import crypto from 'crypto'

export async function POST(request: Request) {
  try {
    const formData = await request.formData()
    const file = formData.get('file') as File | null

    if (!file) {
      return NextResponse.json({ error: 'No file provided' }, { status: 400 })
    }

    const bytes = await file.arrayBuffer()
    const buffer = Buffer.from(bytes)

    const ext = path.extname(file.name) || '.jpg'
    const filename = `${crypto.randomBytes(16).toString('hex')}${ext}`
    const uploadDir = path.join(process.cwd(), 'public', 'uploads')
    
    await mkdir(uploadDir, { recursive: true })
    const filepath = path.join(uploadDir, filename)
    
    await writeFile(filepath, buffer)

    return NextResponse.json({ url: `/uploads/${filename}`, filename })
  } catch (error) {
    return NextResponse.json({ error: 'Error uploading file' }, { status: 500 })
  }
}
