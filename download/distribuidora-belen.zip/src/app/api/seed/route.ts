import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

export async function GET() {
  try {
    // Clean existing data
    await db.productImage.deleteMany()
    await db.product.deleteMany()
    await db.category.deleteMany()
    await db.adminUser.deleteMany()
    await db.siteSettings.deleteMany()

    // Create admin
    await db.adminUser.create({
      data: {
        email: 'admin@belen.com',
        password: 'admin123',
        name: 'Administrador Belén',
      },
    })

    // Create categories
    const camas = await db.category.create({
      data: { name: 'Camas', slug: 'camas', order: 1 },
    })
    const colchones = await db.category.create({
      data: { name: 'Colchones', slug: 'colchones', order: 2 },
    })

    // Create mattresses first (they are referenced by beds)
    const m1 = await db.product.create({
      data: {
        name: 'Colchón Apraiso Individual',
        slug: 'colchon-apraiso-individual',
        description: 'Colchón Apraiso Individual con tecnología de resortes ensacados para máximo confort. Ideal para espacios reducidos, ofrece un soporte óptimo para una persona. Su diseño ergonómico se adapta al cuerpo proporcionando alivio de presión en las zonas más sensibles.',
        price: 3200,
        categoryId: colchones.id,
        isFeatured: false,
        dimensions: '90 x 190 cm',
        material: 'Resortes ensacados',
        images: { create: [{ url: '/uploads/colchon-individual.jpg', alt: 'Colchón Apraiso Individual', order: 0, isPrimary: true }] },
      },
    })

    const m2 = await db.product.create({
      data: {
        name: 'Colchón Apraiso Matrimonial',
        slug: 'colchon-apraiso-matrimonial',
        description: 'Colchón Apraiso Matrimonial con sistema de resortes bonnell de alta resistencia. Perfecto para parejas que buscan un equilibrio entre firmeza y confort. Su superficie de tejido hipoalergénico garantiza un descanso saludable y fresco durante toda la noche.',
        price: 4800,
        categoryId: colchones.id,
        isFeatured: false,
        dimensions: '135 x 190 cm',
        material: 'Resortes bonnell',
        images: { create: [{ url: '/uploads/colchon-matrimonial.jpg', alt: 'Colchón Apraiso Matrimonial', order: 0, isPrimary: true }] },
      },
    })

    const m3 = await db.product.create({
      data: {
        name: 'Colchón Apraiso Queen',
        slug: 'colchon-apraiso-queen',
        description: 'Colchón Apraiso Queen Size con la más avanzada tecnología de resortes ensacados y capa de memory foam. Ofrece un soporte excepcional con sensación de flotación. Su estructura independiente absorbe el movimiento para que usted y su pareja duerman sin interrupciones.',
        price: 5500,
        categoryId: colchones.id,
        isFeatured: true,
        dimensions: '150 x 200 cm',
        material: 'Resortes ensacados + Memory Foam',
        images: { create: [{ url: '/uploads/colchon-queen.jpg', alt: 'Colchón Apraiso Queen', order: 0, isPrimary: true }] },
      },
    })

    const m4 = await db.product.create({
      data: {
        name: 'Colchón Apraiso King',
        slug: 'colchon-apraiso-king',
        description: 'Colchón Apraiso King Size de lujo con triple capa de confort: memory foam, gel y resortes ensacados. La experiencia de descanso definitiva para quienes buscan lo mejor. Su amplio espacio permite máxima libertad de movimiento durante el sueño.',
        price: 6800,
        categoryId: colchones.id,
        isFeatured: true,
        dimensions: '180 x 200 cm',
        material: 'Resortes ensacados + Memory Foam + Gel',
        images: { create: [{ url: '/uploads/colchon-king.jpg', alt: 'Colchón Apraiso King', order: 0, isPrimary: true }] },
      },
    })

    const m5 = await db.product.create({
      data: {
        name: 'Colchón Apraiso King Premium',
        slug: 'colchon-apraiso-king-premium',
        description: 'Colchón Apraiso King Premium ortopédico con tecnología de respuesta progresiva. Diseñado con capas de látex natural, memory foam de alta densidad y resortes ensacados de calibre reforzado. Ideal para personas que requieren soporte extra para la espalda.',
        price: 8500,
        categoryId: colchones.id,
        isFeatured: true,
        dimensions: '180 x 200 cm',
        material: 'Látex + Memory Foam HD + Resortes reforzados',
        images: { create: [{ url: '/uploads/colchon-king-premium.jpg', alt: 'Colchón Apraiso King Premium', order: 0, isPrimary: true }] },
      },
    })

    const m6 = await db.product.create({
      data: {
        name: 'Colchón Apraiso Queen Soft',
        slug: 'colchon-apraiso-queen-soft',
        description: 'Colchón Apraiso Queen Soft con superficie plush ultra suave y base de resortes ensacados. La combinación perfecta de suavidad y soporte para quienes prefieren una sensación de nube al dormir. Incluye tejido antibacterial y tratamiento antiácaros.',
        price: 5800,
        categoryId: colchones.id,
        isFeatured: false,
        dimensions: '150 x 200 cm',
        material: 'Superficie plush + Resortes ensacados',
        images: { create: [{ url: '/uploads/colchon-queen-soft.jpg', alt: 'Colchón Apraiso Queen Soft', order: 0, isPrimary: true }] },
      },
    })

    // Create beds
    await db.product.create({
      data: {
        name: 'Cama Queen Clásica',
        slug: 'cama-queen-clasica',
        description: 'Cama Queen Clásica de Distribuidora Belén fabricada en madera de pino con acabado natural. Diseño atemporal que combina elegancia y funcionalidad. Incluye colchón Apraiso Queen con tecnología de resortes ensacados y memory foam para el descanso perfecto.',
        price: 8500,
        originalPrice: 9500,
        categoryId: camas.id,
        isFeatured: true,
        dimensions: '160 x 210 cm (base)',
        material: 'Madera de pino',
        mattressId: m3.id,
        images: { create: [{ url: '/uploads/cama-queen-clasica.jpg', alt: 'Cama Queen Clásica', order: 0, isPrimary: true }] },
      },
    })

    await db.product.create({
      data: {
        name: 'Cama King Imperial',
        slug: 'cama-king-imperial',
        description: 'Cama King Imperial de Distribuidora Belén en madera de roble con cabecera tallada artesanalmente. Una pieza central para el dormitorio que transmite prestigio y sofisticación. Incluye colchón Apraiso King Premium ortopédico para un descanso de lujo.',
        price: 12000,
        originalPrice: 13500,
        categoryId: camas.id,
        isFeatured: true,
        dimensions: '200 x 210 cm (base)',
        material: 'Madera de roble',
        mattressId: m4.id,
        images: { create: [{ url: '/uploads/cama-king-imperial.jpg', alt: 'Cama King Imperial', order: 0, isPrimary: true }] },
      },
    })

    await db.product.create({
      data: {
        name: 'Cama Matrimonial Elegance',
        slug: 'cama-matrimonial-elegance',
        description: 'Cama Matrimonial Elegance de Distribuidora Belén con estructura en MDF de alta densidad y acabado lacado blanco. Su diseño limpio y moderno se adapta a cualquier estilo de decoración. Incluye colchón Apraiso Matrimonial con resortes bonnell.',
        price: 7200,
        originalPrice: 8000,
        categoryId: camas.id,
        isFeatured: false,
        dimensions: '145 x 200 cm (base)',
        material: 'MDF lacado',
        mattressId: m2.id,
        images: { create: [{ url: '/uploads/cama-matrimonial-elegance.jpg', alt: 'Cama Matrimonial Elegance', order: 0, isPrimary: true }] },
      },
    })

    await db.product.create({
      data: {
        name: 'Cama Queen Moderna',
        slug: 'cama-queen-moderna',
        description: 'Cama Queen Moderna de Distribuidora Belén en melamina con acabado gris carbón. Líneas rectas y minimalistas para un look contemporáneo. Incluye colchón Apraiso Queen Soft con superficie plush ultra suave para un descanso de nubes.',
        price: 9800,
        originalPrice: 11000,
        categoryId: camas.id,
        isFeatured: false,
        dimensions: '160 x 210 cm (base)',
        material: 'Melamina',
        mattressId: m6.id,
        images: { create: [{ url: '/uploads/cama-queen-moderna.jpg', alt: 'Cama Queen Moderna', order: 0, isPrimary: true }] },
      },
    })

    await db.product.create({
      data: {
        name: 'Cama King Premium',
        slug: 'cama-king-premium',
        description: 'Cama King Premium de Distribuidora Belén en madera sólida con cabecera acolchada en tela premium. El epitome del confort y la distinción. Incluye colchón Apraiso King Premium ortopédico con triple capa de confort y tecnología de respuesta progresiva.',
        price: 14500,
        originalPrice: 16000,
        categoryId: camas.id,
        isFeatured: true,
        dimensions: '200 x 210 cm (base)',
        material: 'Madera sólida + Tapiz premium',
        mattressId: m5.id,
        images: { create: [{ url: '/uploads/cama-king-premium.jpg', alt: 'Cama King Premium', order: 0, isPrimary: true }] },
      },
    })

    await db.product.create({
      data: {
        name: 'Cama Individual Comfort',
        slug: 'cama-individual-comfort',
        description: 'Cama Individual Comfort de Distribuidora Belén en madera de pino con diseño compacto y funcional. Perfecta para habitaciones juveniles o espacios de huéspedes. Incluye colchón Apraiso Individual con resortes ensacados para un soporte óptimo.',
        price: 5500,
        originalPrice: 6200,
        categoryId: camas.id,
        isFeatured: false,
        dimensions: '100 x 200 cm (base)',
        material: 'Madera de pino',
        mattressId: m1.id,
        images: { create: [{ url: '/uploads/cama-individual-comfort.jpg', alt: 'Cama Individual Comfort', order: 0, isPrimary: true }] },
      },
    })

    await db.product.create({
      data: {
        name: 'Cama Queen Roma',
        slug: 'cama-queen-roma',
        description: 'Cama Queen Roma de Distribuidora Belén con espectacular cabecera capitoné. Inspirada en el diseño italiano clásico con un toque contemporáneo. Su tapizado en tela de alta calidad y botones decorativos la convierten en una pieza de arte. Incluye colchón Apraiso Queen.',
        price: 10200,
        originalPrice: 11500,
        categoryId: camas.id,
        isFeatured: true,
        dimensions: '160 x 210 cm (base)',
        material: 'Estructura de madera + Cabecera capitoné',
        mattressId: m3.id,
        images: { create: [{ url: '/uploads/cama-queen-roma.jpg', alt: 'Cama Queen Roma', order: 0, isPrimary: true }] },
      },
    })

    await db.product.create({
      data: {
        name: 'Cama King Luxe',
        slug: 'cama-king-luxe',
        description: 'Cama King Luxe de Distribuidora Belén, nuestra pieza más exclusiva. Tapizado completo en tela de alta gama con detalles de costura artesanal. Cada detalle está pensado para crear una experiencia de descanso incomparable. Incluye colchón Apraiso King Premium ortopédico.',
        price: 16000,
        originalPrice: 18000,
        categoryId: camas.id,
        isFeatured: true,
        dimensions: '200 x 210 cm (base)',
        material: 'Tapizado premium + Estructura reforzada',
        mattressId: m5.id,
        images: { create: [{ url: '/uploads/cama-king-luxe.jpg', alt: 'Cama King Luxe', order: 0, isPrimary: true }] },
      },
    })

    // Create site settings
    const defaultSettings = [
      { key: 'whatsapp_number', value: '51999999999' },
      { key: 'phone', value: '+51 (01) 234-5678' },
      { key: 'email', value: 'ventas@distribuidorabelen.com' },
      { key: 'address', value: 'Av. Principal #123, Lima, Perú' },
      { key: 'business_hours', value: 'Lun-Sáb: 9:00 - 19:00' },
      { key: 'whatsapp_message', value: 'Hola, estoy interesado/a en {product} de Distribuidora Belén' },
      { key: 'currency_symbol', value: 'S/' },
      { key: 'currency_code', value: 'PEN' },
      { key: 'show_whatsapp_float', value: 'true' },
    ]
    await db.siteSettings.createMany({ data: defaultSettings })

    return NextResponse.json({ 
      success: true, 
      message: 'Base de datos poblada con 14 productos, 2 categorías, usuario admin y configuración del sitio',
      admin: { email: 'admin@belen.com', password: 'admin123' }
    })
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Unknown error'
    return NextResponse.json({ error: msg }, { status: 500 })
  }
}
