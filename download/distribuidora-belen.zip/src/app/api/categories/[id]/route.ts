import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const body = await request.json()
    const category = await db.category.update({
      where: { id },
      data: { name: body.name, slug: body.slug, order: body.order },
    })
    return NextResponse.json(category)
  } catch (error) {
    return NextResponse.json({ error: 'Error updating category' }, { status: 500 })
  }
}

export async function DELETE(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const productsCount = await db.product.count({ where: { categoryId: id } })
    if (productsCount > 0) {
      return NextResponse.json({ error: 'No se puede eliminar una categoría con productos' }, { status: 400 })
    }
    await db.category.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error) {
    return NextResponse.json({ error: 'Error deleting category' }, { status: 500 })
  }
}
