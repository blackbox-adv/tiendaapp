import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/components/theme-provider";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Distribuidora Belén | Camas y Colchones de Alta Calidad",
  description: "Distribuidora Belén - Tu descanso, nuestra pasión. Camas propias y colchones Apraiso de la más alta calidad para un sueño reparador.",
  keywords: ["camas", "colchones", "Apraiso", "Distribuidora Belén", "muebles", "descanso"],
  icons: {
    icon: "/favicon.ico",
  },
  openGraph: {
    title: "Distribuidora Belén",
    description: "Camas y colchones de alta calidad. Tu descanso, nuestra pasión.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem={false}>
          {children}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}
