export interface Product {
  id: string
  name: string
  slug: string
  description: string
  price: number
  originalPrice: number | null
  categoryId: string
  isActive: boolean
  isFeatured: boolean
  dimensions: string | null
  material: string | null
  mattressId: string | null
  createdAt: string
  updatedAt: string
  category: Category
  images: ProductImage[]
  mattress?: Product | null
  beds?: Product[]
}

export interface Category {
  id: string
  name: string
  slug: string
  order: number
  _count?: { products: number }
}

export interface ProductImage {
  id: string
  url: string
  alt: string | null
  order: number
  isPrimary: boolean
  productId: string
}
