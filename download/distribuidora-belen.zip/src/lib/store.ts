import { create } from 'zustand'

export type PageRoute = 
  | { page: 'home' }
  | { page: 'catalog'; filters?: { category?: string; search?: string } }
  | { page: 'product'; productId: string }
  | { page: 'admin-login' }
  | { page: 'admin' }
  | { page: 'admin-products' }
  | { page: 'admin-product-form'; productId?: string }
  | { page: 'admin-categories' }
  | { page: 'admin-settings' }

interface AdminState {
  isAuthenticated: boolean
  adminName: string
  adminEmail: string
  login: (email: string, name: string) => void
  logout: () => void
}

interface StoreState {
  route: PageRoute
  history: PageRoute[]
  navigate: (route: PageRoute) => void
  goBack: () => void
  admin: AdminState
}

export const useStore = create<StoreState>((set) => ({
  route: { page: 'home' },
  history: [{ page: 'home' }],
  navigate: (route) =>
    set((state) => ({
      route,
      history: [...state.history, route],
    })),
  goBack: () =>
    set((state) => {
      const newHistory = state.history.slice(0, -1)
      const prev = newHistory[newHistory.length - 1] || { page: 'home' as const }
      return {
        route: prev,
        history: newHistory.length > 0 ? newHistory : [{ page: 'home' as const }],
      }
    }),
  admin: {
    isAuthenticated: false,
    adminName: '',
    adminEmail: '',
    login: (email, name) =>
      set((state) => ({
        admin: { ...state.admin, isAuthenticated: true, adminEmail: email, adminName: name },
      })),
    logout: () =>
      set((state) => ({
        admin: { ...state.admin, isAuthenticated: false, adminName: '', adminEmail: '' },
        route: { page: 'home' },
        history: [{ page: 'home' }],
      })),
  },
}))
