'use client'

import Link from 'next/link'
import { useStore } from '@/lib/store'
import { Button } from '@/components/ui/button'
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from '@/components/ui/sheet'
import { Badge } from '@/components/ui/badge'
import { Menu, ShoppingCart, User, X } from 'lucide-react'
import { useState } from 'react'

export default function Header() {
  const { route, navigate, admin } = useStore()
  const [open, setOpen] = useState(false)

  const isHome = route.page === 'home'
  const isCatalogCat = (cat?: string) => route.page === 'catalog' && (route.filters?.category === cat)

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-border/50 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Logo */}
          <button
            onClick={() => { navigate({ page: 'home' }); setOpen(false) }}
            className="flex items-center gap-3 hover:opacity-80 transition-opacity"
          >
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-lg sm:text-xl">B</span>
            </div>
            <div className="hidden sm:block">
              <h1 className="text-lg font-bold text-primary leading-tight">Distribuidora</h1>
              <p className="text-xs text-gold font-semibold tracking-widest uppercase">Belén</p>
            </div>
            <div className="sm:hidden">
              <h1 className="text-sm font-bold text-primary leading-tight">Dist. Belén</h1>
            </div>
          </button>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-1">
            <Button
              variant={isHome ? 'default' : 'ghost'}
              onClick={() => navigate({ page: 'home' })}
              className={isHome ? 'bg-primary text-white' : 'text-foreground hover:text-primary hover:bg-warm-gray'}
            >
              Inicio
            </Button>
            <Button
              variant={isCatalogCat(undefined) ? 'default' : 'ghost'}
              onClick={() => navigate({ page: 'catalog' })}
              className={isCatalogCat(undefined) ? 'bg-primary text-white' : 'text-foreground hover:text-primary hover:bg-warm-gray'}
            >
              Productos
            </Button>
            <Button
              variant={isCatalogCat('camas') ? 'default' : 'ghost'}
              onClick={() => navigate({ page: 'catalog', filters: { category: 'camas' } })}
              className={isCatalogCat('camas') ? 'bg-primary text-white' : 'text-foreground hover:text-primary hover:bg-warm-gray'}
            >
              Camas
            </Button>
            <Button
              variant={isCatalogCat('colchones') ? 'default' : 'ghost'}
              onClick={() => navigate({ page: 'catalog', filters: { category: 'colchones' } })}
              className={isCatalogCat('colchones') ? 'bg-primary text-white' : 'text-foreground hover:text-primary hover:bg-warm-gray'}
            >
              Colchones
            </Button>
          </nav>

          {/* Right Side */}
          <div className="flex items-center gap-2">
            {/* Admin Button */}
            {admin.isAuthenticated ? (
              <Button
                variant="outline"
                size="sm"
                onClick={() => navigate({ page: 'admin' })}
                className="hidden sm:flex items-center gap-2 border-gold text-gold hover:bg-gold hover:text-white"
              >
                <User className="h-4 w-4" />
                <span className="text-xs">{admin.adminName}</span>
              </Button>
            ) : (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate({ page: 'admin-login' })}
                className="hidden sm:flex items-center gap-1 text-muted-foreground hover:text-primary"
              >
                <User className="h-4 w-4" />
              </Button>
            )}

            {/* Mobile Menu */}
            <Sheet open={open} onOpenChange={setOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-72 bg-white p-0">
                <SheetTitle className="sr-only">Menú de navegación</SheetTitle>
                <div className="flex flex-col h-full">
                  <div className="p-6 border-b border-border">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
                        <span className="text-primary-foreground font-bold text-lg">B</span>
                      </div>
                      <div>
                        <h2 className="font-bold text-primary">Distribuidora</h2>
                        <p className="text-xs text-gold font-semibold tracking-widest">BELÉN</p>
                      </div>
                    </div>
                  </div>
                  <nav className="flex-1 p-4">
                    {[
                      { label: 'Inicio', page: 'home' as const, filter: undefined as string | undefined },
                      { label: 'Todos los Productos', page: 'catalog' as const, filter: undefined as string | undefined },
                      { label: 'Camas', page: 'catalog' as const, filter: 'camas' },
                      { label: 'Colchones Apraiso', page: 'catalog' as const, filter: 'colchones' },
                    ].map((item) => {
                      const itemActive = item.page === 'home' ? isHome : isCatalogCat(item.filter)
                      return (
                        <button
                          key={item.label}
                          onClick={() => {
                            navigate(item.filter
                              ? { page: item.page, filters: { category: item.filter } }
                              : { page: item.page }
                            )
                            setOpen(false)
                          }}
                          className={`w-full text-left px-4 py-3 rounded-lg font-medium transition-colors ${
                            itemActive
                              ? 'bg-primary text-white'
                              : 'text-foreground hover:bg-warm-gray'
                          }`}
                        >
                          {item.label}
                        </button>
                      )
                    })}
                    <div className="border-t border-border my-4" />
                    <button
                      onClick={() => {
                        navigate({ page: admin.isAuthenticated ? 'admin' : 'admin-login' })
                        setOpen(false)
                      }}
                      className="w-full text-left px-4 py-3 rounded-lg text-muted-foreground hover:bg-warm-gray transition-colors"
                    >
                      {admin.isAuthenticated ? 'Panel Admin' : 'Acceso Admin'}
                    </button>
                  </nav>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  )
}
