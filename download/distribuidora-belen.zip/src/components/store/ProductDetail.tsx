'use client'

import { useState, useEffect } from 'react'
import { useStore } from '@/lib/store'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { Skeleton } from '@/components/ui/skeleton'
import {
  ArrowLeft, Bed, Ruler, Layers, ShoppingCart, Phone, Check, Star, ChevronLeft, ChevronRight,
  MessageCircle
} from 'lucide-react'
import type { Product } from '@/lib/types'
import { motion, AnimatePresence } from 'framer-motion'

export default function ProductDetail() {
  const { route, navigate, goBack } = useStore()
  const productId = route.page === 'product' ? route.productId : null
  const [product, setProduct] = useState<Product | null>(null)
  const [loading, setLoading] = useState(true)
  const [selectedImageIdx, setSelectedImageIdx] = useState(0)
  const [showMattress, setShowMattress] = useState(false)

  useEffect(() => {
    if (!productId) return
    let cancelled = false
    fetch(`/api/products/${productId}`)
      .then(res => res.json())
      .then(data => { if (!cancelled) { setProduct(data); setSelectedImageIdx(0); setLoading(false) } })
      .catch(() => { if (!cancelled) { setProduct(null); setLoading(false) } })
    return () => { cancelled = true }
  }, [productId])

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Skeleton className="h-8 w-32 mb-8" />
        <div className="grid md:grid-cols-2 gap-8 lg:gap-12">
          <Skeleton className="aspect-square rounded-xl" />
          <div className="space-y-4">
            <Skeleton className="h-8 w-3/4" />
            <Skeleton className="h-4 w-1/2" />
            <Skeleton className="h-10 w-1/3" />
            <Skeleton className="h-24 w-full" />
          </div>
        </div>
      </div>
    )
  }

  if (!product) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
        <h2 className="text-2xl font-bold mb-4">Producto no encontrado</h2>
        <Button onClick={() => navigate({ page: 'catalog' })}>Ver todos los productos</Button>
      </div>
    )
  }

  const images = product.images || []
  const primaryImg = images[selectedImageIdx] || images[0]
  const hasDiscount = product.originalPrice && product.originalPrice > product.price
  const discountPercent = hasDiscount
    ? Math.round(((product.originalPrice! - product.price) / product.originalPrice!) * 100)
    : 0
  const isBed = product.category?.slug === 'camas'
  const mattress = isBed ? product.mattress : null

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-10 animate-fadeIn">
      {/* Breadcrumb */}
      <button
        onClick={goBack}
        className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors mb-6 sm:mb-8"
      >
        <ArrowLeft className="h-4 w-4" />
        Volver
      </button>

      <div className="grid md:grid-cols-2 gap-6 sm:gap-8 lg:gap-12">
        {/* Image Gallery */}
        <div className="space-y-3">
          {/* Main Image */}
          <div className="relative aspect-square rounded-xl overflow-hidden bg-warm-gray group">
            {primaryImg ? (
              <AnimatePresence mode="wait">
                <motion.img
                  key={primaryImg.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  src={primaryImg.url}
                  alt={primaryImg.alt || product.name}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement
                    target.style.display = 'none'
                  }}
                />
              </AnimatePresence>
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <Bed className="h-16 w-16 text-muted-foreground/30" />
              </div>
            )}

            {images.length > 1 && (
              <>
                <button
                  onClick={() => setSelectedImageIdx(prev => prev === 0 ? images.length - 1 : prev - 1)}
                  className="absolute left-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/80 hover:bg-white shadow-lg flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <ChevronLeft className="h-5 w-5" />
                </button>
                <button
                  onClick={() => setSelectedImageIdx(prev => prev === images.length - 1 ? 0 : prev + 1)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/80 hover:bg-white shadow-lg flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <ChevronRight className="h-5 w-5" />
                </button>
              </>
            )}

            {/* Badges */}
            <div className="absolute top-3 left-3 flex flex-col gap-1.5">
              {product.isFeatured && (
                <Badge className="bg-gold text-white text-xs">★ Destacado</Badge>
              )}
              {hasDiscount && (
                <Badge className="bg-red-500 text-white text-xs">-{discountPercent}%</Badge>
              )}
            </div>
          </div>

          {/* Thumbnails */}
          {images.length > 1 && (
            <div className="flex gap-2 overflow-x-auto pb-1">
              {images.map((img, idx) => (
                <button
                  key={img.id}
                  onClick={() => setSelectedImageIdx(idx)}
                  className={`flex-shrink-0 w-16 h-16 sm:w-20 sm:h-20 rounded-lg overflow-hidden border-2 transition-all ${
                    idx === selectedImageIdx ? 'border-gold shadow-md' : 'border-transparent opacity-60 hover:opacity-100'
                  }`}
                >
                  <img
                    src={img.url}
                    alt={img.alt || product.name}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement
                      target.style.display = 'none'
                    }}
                  />
                </button>
              ))}
            </div>
          )}

          {/* Mattress Preview for Beds */}
          {mattress && mattress.images && mattress.images.length > 0 && (
            <Card
              className="overflow-hidden cursor-pointer border-2 border-gold/30 hover:border-gold transition-colors"
              onClick={() => setShowMattress(!showMattress)}
            >
              <CardContent className="p-4 flex items-center gap-4">
                <div className="w-20 h-16 rounded-lg overflow-hidden bg-warm-gray flex-shrink-0">
                  <img
                    src={mattress.images[0].url}
                    alt={mattress.name}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement
                      target.style.display = 'none'
                    }}
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-gold font-semibold uppercase tracking-wider">Incluye</p>
                  <p className="font-semibold text-sm text-foreground truncate">{mattress.name}</p>
                  <p className="text-xs text-muted-foreground">
                    Valor del colchón: S/ {mattress.price.toLocaleString('es-PE')}
                  </p>
                </div>
                <ChevronRight className={`h-5 w-5 text-muted-foreground transition-transform ${showMattress ? 'rotate-90' : ''}`} />
              </CardContent>
            </Card>
          )}
        </div>

        {/* Product Info */}
        <div className="space-y-6">
          {/* Category & Brand */}
          <div>
            <p className="text-sm text-gold font-semibold uppercase tracking-wider mb-1">
              {product.category?.name} • Distribuidora Belén
            </p>
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-foreground leading-tight">
              {product.name}
            </h1>
          </div>

          {/* Rating */}
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-0.5">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star key={star} className="h-4 w-4 fill-gold text-gold" />
              ))}
            </div>
            <span className="text-sm text-muted-foreground">(5.0) • Excelente calidad</span>
          </div>

          <Separator />

          {/* Price */}
          <div className="space-y-1">
            <div className="flex items-baseline gap-3">
              <span className="text-3xl sm:text-4xl font-bold text-primary">
                S/ {product.price.toLocaleString('es-PE')}
              </span>
              {hasDiscount && (
                <span className="text-lg text-muted-foreground line-through">
                  S/ {product.originalPrice!.toLocaleString('es-PE')}
                </span>
              )}
            </div>
            {hasDiscount && (
              <p className="text-sm text-red-500 font-semibold">
                Ahorras S/ {(product.originalPrice! - product.price).toLocaleString('es-PE')}
              </p>
            )}
            <p className="text-xs text-muted-foreground">Precio incluye IVA</p>
          </div>

          {/* Description */}
          <div>
            <h3 className="font-semibold text-foreground mb-2">Descripción</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              {product.description}
            </p>
          </div>

          <Separator />

          {/* Specs */}
          <div className="grid grid-cols-2 gap-4">
            {product.dimensions && (
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-lg bg-warm-gray flex items-center justify-center flex-shrink-0">
                  <Ruler className="h-4 w-4 text-primary" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Dimensiones</p>
                  <p className="text-sm font-medium">{product.dimensions}</p>
                </div>
              </div>
            )}
            {product.material && (
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-lg bg-warm-gray flex items-center justify-center flex-shrink-0">
                  <Layers className="h-4 w-4 text-primary" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Material</p>
                  <p className="text-sm font-medium">{product.material}</p>
                </div>
              </div>
            )}
          </div>

          {/* Features */}
          <div className="space-y-2">
            {[
              'Envío gratuito',
              'Garantía de calidad',
              isBed ? 'Incluye colchón Apraiso' : 'Tecnología avanzada',
              'Pago a meses sin intereses',
            ].map((feature) => (
              <div key={feature} className="flex items-center gap-2">
                <Check className="h-4 w-4 text-green-600 flex-shrink-0" />
                <span className="text-sm text-foreground">{feature}</span>
              </div>
            ))}
          </div>

          {/* CTA Buttons */}
          <div className="space-y-3 pt-2">
            <a
              href={`https://wa.me/?text=${encodeURIComponent(`Hola, estoy interesado/a en ${product.name} (S/ ${product.price.toLocaleString('es-PE')}) de Distribuidora Belén`)}`}
              target="_blank"
              rel="noopener noreferrer"
            >
              <Button size="lg" className="w-full h-12 sm:h-14 bg-[#25D366] hover:bg-[#20BD5A] text-white font-semibold text-base rounded-lg">
                <MessageCircle className="mr-2 h-5 w-5" />
                Comprar por WhatsApp
              </Button>
            </a>

            {isBed && mattress && (
              <Button
                variant="outline"
                size="lg"
                className="w-full h-12 sm:h-14 border-gold text-gold hover:bg-gold hover:text-white font-semibold rounded-lg transition-all"
                onClick={() => navigate({ page: 'product', productId: mattress.id })}
              >
                Ver colchón por separado
                <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Mattress Detail Expandable */}
      <AnimatePresence>
        {showMattress && mattress && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="mt-8 overflow-hidden"
          >
            <Card className="border-gold/30">
              <CardContent className="p-6 sm:p-8">
                <h3 className="text-lg font-bold text-primary mb-4 flex items-center gap-2">
                  <Bed className="h-5 w-5" />
                  Detalle del Colchón Incluido
                </h3>
                <div className="grid sm:grid-cols-2 gap-6">
                  <div className="space-y-3">
                    {mattress.images[0] && (
                      <div className="aspect-video rounded-lg overflow-hidden bg-warm-gray">
                        <img
                          src={mattress.images[0].url}
                          alt={mattress.name}
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            const target = e.target as HTMLImageElement
                            target.style.display = 'none'
                          }}
                        />
                      </div>
                    )}
                  </div>
                  <div className="space-y-3">
                    <Badge className="bg-gold text-white text-xs">Apraiso</Badge>
                    <h4 className="text-xl font-bold">{mattress.name}</h4>
                    <p className="text-sm text-muted-foreground">{mattress.description}</p>
                    {mattress.dimensions && (
                      <p className="text-sm font-medium">Dimensiones: {mattress.dimensions}</p>
                    )}
                    {mattress.material && (
                      <p className="text-sm font-medium">Material: {mattress.material}</p>
                    )}
                    <div className="pt-2">
                      <Button
                        variant="outline"
                        className="border-gold text-gold hover:bg-gold hover:text-white"
                        onClick={() => navigate({ page: 'product', productId: mattress.id })}
                      >
                        Ver producto completo
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
