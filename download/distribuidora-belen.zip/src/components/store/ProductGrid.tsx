'use client'

import { useState, useEffect, useRef } from 'react'
import { useStore } from '@/lib/store'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Search, SlidersHorizontal, X, ChevronDown } from 'lucide-react'
import ProductCard from './ProductCard'
import { Skeleton } from '@/components/ui/skeleton'
import type { Product, Category } from '@/lib/types'

interface ProductGridProps {
  categoryFilter?: string
  searchQuery?: string
  showFilters?: boolean
}

export default function ProductGrid({ categoryFilter, searchQuery: initialSearch, showFilters = true }: ProductGridProps) {
  const { navigate } = useStore()
  const [products, setProducts] = useState<Product[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState(initialSearch || '')
  const [activeCategory, setActiveCategory] = useState(categoryFilter || 'todos')
  const [sortBy, setSortBy] = useState<'name' | 'price-asc' | 'price-desc' | 'newest'>('newest')
  const [showSort, setShowSort] = useState(false)

  const initializedRef = useRef(true)

  useEffect(() => {
    let cancelled = false
    const doFetch = async () => {
      const params = new URLSearchParams()
      if (activeCategory && activeCategory !== 'todos') params.set('category', activeCategory)
      if (search) params.set('search', search)

      const res = await fetch(`/api/products?${params}`)
      if (!cancelled) {
        const data = await res.json()
        let sorted = data
        switch (sortBy) {
          case 'price-asc': sorted = [...data].sort((a: Product, b: Product) => a.price - b.price); break
          case 'price-desc': sorted = [...data].sort((a: Product, b: Product) => b.price - a.price); break
          case 'name': sorted = [...data].sort((a: Product, b: Product) => a.name.localeCompare(b.name)); break
        }
        setProducts(sorted)
        setLoading(false)
      }
    }
    doFetch().catch(() => { if (!cancelled) { setProducts([]); setLoading(false) } })
    return () => { cancelled = true }
  }, [activeCategory, search, sortBy])

  useEffect(() => {
    let cancelled = false
    fetch('/api/categories')
      .then(res => res.json())
      .then(data => { if (!cancelled) setCategories(data) })
      .catch(() => {})
    return () => { cancelled = true }
  }, [])

  return (
    <section className="py-8 sm:py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Search & Sort */}
        <div className="flex flex-col sm:flex-row gap-3 mb-6 sm:mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar productos..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10 pr-10 h-11 rounded-lg border-border bg-white"
            />
            {search && (
              <button onClick={() => setSearch('')} className="absolute right-3 top-1/2 -translate-y-1/2">
                <X className="h-4 w-4 text-muted-foreground hover:text-foreground" />
              </button>
            )}
          </div>

          <div className="relative">
            <Button
              variant="outline"
              onClick={() => setShowSort(!showSort)}
              className="h-11 w-full sm:w-48 justify-between rounded-lg border-border"
            >
              <span className="flex items-center gap-2">
                <SlidersHorizontal className="h-4 w-4" />
                {sortBy === 'newest' ? 'Más recientes' :
                 sortBy === 'price-asc' ? 'Precio: Menor' :
                 sortBy === 'price-desc' ? 'Precio: Mayor' : 'Nombre'}
              </span>
              <ChevronDown className="h-4 w-4" />
            </Button>
            {showSort && (
              <div className="absolute top-full left-0 right-0 sm:w-48 mt-1 bg-white border border-border rounded-lg shadow-lg z-20 overflow-hidden">
                {[
                  { value: 'newest', label: 'Más recientes' },
                  { value: 'price-asc', label: 'Precio: Menor a Mayor' },
                  { value: 'price-desc', label: 'Precio: Mayor a Menor' },
                  { value: 'name', label: 'Nombre (A-Z)' },
                ].map((option) => (
                  <button
                    key={option.value}
                    onClick={() => { setSortBy(option.value as typeof sortBy); setShowSort(false) }}
                    className={`w-full text-left px-4 py-2.5 text-sm hover:bg-warm-gray transition-colors ${sortBy === option.value ? 'text-primary font-semibold bg-warm-gray' : 'text-foreground'}`}
                  >
                    {option.label}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Category Filters */}
        {showFilters && (
          <div className="flex flex-wrap gap-2 mb-6 sm:mb-8">
            <Button
              variant={activeCategory === 'todos' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setActiveCategory('todos')}
              className={activeCategory === 'todos' ? 'bg-primary text-white' : 'border-border hover:border-primary hover:text-primary'}
            >
              Todos
            </Button>
            {categories.map((cat) => (
              <Button
                key={cat.id}
                variant={activeCategory === cat.slug ? 'default' : 'outline'}
                size="sm"
                onClick={() => setActiveCategory(cat.slug)}
                className={activeCategory === cat.slug ? 'bg-primary text-white' : 'border-border hover:border-primary hover:text-primary'}
              >
                {cat.name}
                {cat._count && (
                  <span className="ml-1.5 text-xs opacity-70">({cat._count.products})</span>
                )}
              </Button>
            ))}
          </div>
        )}

        {/* Results count */}
        {!loading && (
          <p className="text-sm text-muted-foreground mb-6">
            {products.length} producto{products.length !== 1 ? 's' : ''} encontrado{products.length !== 1 ? 's' : ''}
          </p>
        )}

        {/* Grid */}
        {loading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="space-y-3">
                <Skeleton className="aspect-square rounded-xl" />
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
                <Skeleton className="h-5 w-1/3" />
              </div>
            ))}
          </div>
        ) : products.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-20 h-20 rounded-full bg-warm-gray flex items-center justify-center mx-auto mb-4">
              <Search className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-2">No se encontraron productos</h3>
            <p className="text-sm text-muted-foreground">
              Intenta con otra búsqueda o categoría
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
            {products.map((product, idx) => (
              <ProductCard key={product.id} product={product} index={idx} />
            ))}
          </div>
        )}
      </div>
    </section>
  )
}
