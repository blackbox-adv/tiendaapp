'use client'

import { useStore } from '@/lib/store'
import { Button } from '@/components/ui/button'
import { ArrowRight, ChevronDown } from 'lucide-react'
import { motion } from 'framer-motion'

export default function HeroBanner() {
  const { navigate } = useStore()

  const scrollToProducts = () => {
    navigate({ page: 'catalog' })
  }

  return (
    <section className="relative overflow-hidden bg-primary">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0" style={{
          backgroundImage: `radial-gradient(circle at 25% 25%, rgba(200,164,86,0.3) 0%, transparent 50%),
                           radial-gradient(circle at 75% 75%, rgba(200,164,86,0.2) 0%, transparent 50%)`,
        }} />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24 lg:py-32">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-16 items-center">
          {/* Text Content */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7 }}
            className="text-center lg:text-left"
          >
            <div className="inline-block mb-4">
              <span className="text-gold text-xs sm:text-sm font-semibold tracking-[0.3em] uppercase">
                Calidad Premium
              </span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-bold text-white leading-tight mb-4 sm:mb-6">
              Tu descanso,{' '}
              <span className="text-gold-gradient">nuestra pasión</span>
            </h1>

            <p className="text-base sm:text-lg text-white/70 mb-8 max-w-lg mx-auto lg:mx-0 leading-relaxed">
              Descubre nuestra exclusiva colección de camas de diseño propio y colchones Apraiso. 
              Calidad artesanal para las noches más placenteras de tu vida.
            </p>

            <div className="flex flex-col sm:flex-row gap-3 justify-center lg:justify-start">
              <Button
                onClick={scrollToProducts}
                size="lg"
                className="bg-gold hover:bg-gold-light text-white font-semibold text-base px-8 py-6 rounded-lg transition-all duration-300 hover:shadow-lg hover:shadow-gold/25"
              >
                Ver Colección
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button
                onClick={() => navigate({ page: 'catalog', filters: { category: 'camas' } })}
                variant="outline"
                size="lg"
                className="border-white/30 text-white hover:bg-white/10 hover:text-white font-semibold text-base px-8 py-6 rounded-lg"
              >
                Camas + Colchón
              </Button>
            </div>

            {/* Trust badges */}
            <div className="flex flex-wrap items-center gap-6 mt-8 sm:mt-10 justify-center lg:justify-start">
              <div className="text-center">
                <p className="text-2xl font-bold text-gold">10+</p>
                <p className="text-xs text-white/50">Años de experiencia</p>
              </div>
              <div className="w-px h-10 bg-white/20" />
              <div className="text-center">
                <p className="text-2xl font-bold text-gold">500+</p>
                <p className="text-xs text-white/50">Clientes felices</p>
              </div>
              <div className="w-px h-10 bg-white/20" />
              <div className="text-center">
                <p className="text-2xl font-bold text-gold">100%</p>
                <p className="text-xs text-white/50">Garantía</p>
              </div>
            </div>
          </motion.div>

          {/* Visual Element */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="hidden lg:block relative"
          >
            <div className="relative">
              {/* Decorative frame */}
              <div className="absolute -inset-4 border-2 border-gold/20 rounded-2xl rotate-2" />
              <div className="absolute -inset-4 border border-gold/10 rounded-2xl -rotate-1" />
              
              {/* Main image placeholder */}
              <div className="relative rounded-xl overflow-hidden aspect-[4/3] bg-gradient-to-br from-navy-light to-primary">
                <img
                  src="/uploads/hero-banner.jpg"
                  alt="Colección de camas y colchones Distribuidora Belén"
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement
                    target.style.display = 'none'
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-primary/80 via-transparent to-transparent" />
                <div className="absolute bottom-6 left-6 right-6">
                  <p className="text-gold font-semibold text-sm tracking-wider uppercase">Nueva Colección</p>
                  <p className="text-white text-xl font-bold mt-1">Camas Belén 2025</p>
                </div>
              </div>

              {/* Floating badge */}
              <div className="absolute -bottom-4 -left-4 bg-white rounded-lg shadow-xl p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gold/10 flex items-center justify-center">
                    <span className="text-gold font-bold text-sm">★</span>
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-foreground">Apraiso</p>
                    <p className="text-xs text-muted-foreground">Colchones Premium</p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Bottom wave */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 60" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full">
          <path d="M0 60L48 55C96 50 192 40 288 33.3C384 26.7 480 23.3 576 25C672 26.7 768 33.3 864 36.7C960 40 1056 40 1152 36.7C1248 33.3 1344 26.7 1392 23.3L1440 20V60H1392C1344 60 1248 60 1152 60C1056 60 960 60 864 60C768 60 672 60 576 60C480 60 384 60 288 60C192 60 96 60 48 60H0Z" fill="#FAFAF8"/>
        </svg>
      </div>
    </section>
  )
}
