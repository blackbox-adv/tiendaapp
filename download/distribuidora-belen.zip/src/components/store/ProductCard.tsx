'use client'

import { useStore } from '@/lib/store'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Eye, ShoppingCart } from 'lucide-react'
import { motion } from 'framer-motion'
import type { Product } from '@/lib/types'

interface ProductCardProps {
  product: Product
  index?: number
}

export default function ProductCard({ product, index = 0 }: ProductCardProps) {
  const { navigate } = useStore()

  const primaryImage = product.images?.find(img => img.isPrimary) || product.images?.[0]
  const hasDiscount = product.originalPrice && product.originalPrice > product.price
  const discountPercent = hasDiscount
    ? Math.round(((product.originalPrice! - product.price) / product.originalPrice!) * 100)
    : 0

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: index * 0.05 }}
    >
      <Card
        className="group cursor-pointer border-0 shadow-sm hover:shadow-xl transition-all duration-500 overflow-hidden bg-white"
        onClick={() => navigate({ page: 'product', productId: product.id })}
      >
        {/* Image */}
        <div className="relative aspect-square overflow-hidden bg-warm-gray">
          {primaryImage ? (
            <img
              src={primaryImage.url}
              alt={primaryImage.alt || product.name}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              onError={(e) => {
                const target = e.target as HTMLImageElement
                target.style.display = 'none'
              }}
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-muted-foreground">
              <ShoppingCart className="h-12 w-12 opacity-30" />
            </div>
          )}

          {/* Overlay on hover */}
          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-all duration-300 flex items-center justify-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              whileHover={{ opacity: 1, scale: 1 }}
              className="opacity-0 group-hover:opacity-100 transition-opacity duration-300"
            >
              <Button size="sm" className="bg-white text-primary hover:bg-white/90 shadow-lg">
                <Eye className="h-4 w-4 mr-1" />
                Ver más
              </Button>
            </motion.div>
          </div>

          {/* Badges */}
          <div className="absolute top-3 left-3 flex flex-col gap-1.5">
            {product.isFeatured && (
              <Badge className="bg-gold text-white text-[10px] px-2 py-0.5 font-semibold">
                ★ Destacado
              </Badge>
            )}
            {hasDiscount && (
              <Badge className="bg-red-500 text-white text-[10px] px-2 py-0.5 font-semibold">
                -{discountPercent}%
              </Badge>
            )}
            {product.category?.slug === 'camas' && (
              <Badge className="bg-primary text-white text-[10px] px-2 py-0.5 font-semibold">
                + Colchón
              </Badge>
            )}
          </div>
        </div>

        {/* Content */}
        <CardContent className="p-4">
          <p className="text-[11px] text-muted-foreground font-medium uppercase tracking-wider mb-1">
            {product.category?.name}
            {product.category?.slug === 'camas' && ' • Incluye colchón Apraiso'}
          </p>

          <h3 className="font-semibold text-foreground text-sm sm:text-base leading-tight mb-2 line-clamp-2 group-hover:text-primary transition-colors">
            {product.name}
          </h3>

          {/* Price */}
          <div className="flex items-baseline gap-2">
            <span className="text-lg font-bold text-primary">
              S/ {product.price.toLocaleString('es-PE')}
            </span>
            {hasDiscount && (
              <span className="text-sm text-muted-foreground line-through">
                S/ {product.originalPrice!.toLocaleString('es-PE')}
              </span>
            )}
          </div>

          {product.dimensions && (
            <p className="text-xs text-muted-foreground mt-1.5">
              {product.dimensions}
            </p>
          )}
        </CardContent>
      </Card>
    </motion.div>
  )
}
