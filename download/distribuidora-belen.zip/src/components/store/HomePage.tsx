'use client'

import { useState, useEffect } from 'react'
import { useStore } from '@/lib/store'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { ArrowRight, Bed, Shield, Truck, Star, Award } from 'lucide-react'
import { motion } from 'framer-motion'
import ProductCard from './ProductCard'
import HeroBanner from './HeroBanner'
import type { Product, Category } from '@/lib/types'

export default function HomePage() {
  const { navigate } = useStore()
  const [featured, setFeatured] = useState<Product[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [prodRes, catRes] = await Promise.all([
          fetch('/api/products?featured=true'),
          fetch('/api/categories'),
        ])
        const [prodData, catData] = await Promise.all([prodRes.json(), catRes.json()])
        setFeatured(prodData.slice(0, 6))
        setCategories(catData)
      } catch { /* ignore */ }
      setLoading(false)
    }
    fetchData()
  }, [])

  const features = [
    { icon: Shield, title: 'Garantía Total', desc: 'Todos nuestros productos cuentan con garantía de fábrica y respaldo de Distribuidora Belén.' },
    { icon: Truck, title: 'Envío Gratuito', desc: 'Realizamos envíos a toda la república sin costo adicional en tu compra.' },
    { icon: Star, title: 'Calidad Premium', desc: 'Seleccionamos cuidadosamente cada material para garantizar el mejor descanso.' },
    { icon: Award, title: 'Atención Personalizada', desc: 'Nuestro equipo te asesora para encontrar la cama y colchón perfectos.' },
  ]

  return (
    <div>
      {/* Hero */}
      <HeroBanner />

      {/* Features Strip */}
      <section className="py-10 sm:py-14 bg-warm-gray">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
            {features.map((feat, idx) => (
              <motion.div
                key={feat.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                className="text-center"
              >
                <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-xl bg-white shadow-sm flex items-center justify-center mx-auto mb-3">
                  <feat.icon className="h-6 w-6 sm:h-7 sm:w-7 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground text-sm sm:text-base mb-1">{feat.title}</h3>
                <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed hidden sm:block">{feat.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-10 sm:py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-end justify-between mb-8">
            <div>
              <span className="text-gold text-xs font-semibold tracking-[0.2em] uppercase">Selección especial</span>
              <h2 className="text-2xl sm:text-3xl font-bold text-foreground mt-1">Productos Destacados</h2>
            </div>
            <Button
              variant="ghost"
              onClick={() => navigate({ page: 'catalog' })}
              className="text-primary hover:bg-warm-gray hidden sm:flex items-center gap-1"
            >
              Ver todos <ArrowRight className="h-4 w-4" />
            </Button>
          </div>

          {loading ? (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="space-y-3">
                  <div className="aspect-square bg-gray-200 rounded-xl animate-pulse" />
                  <div className="h-4 bg-gray-200 rounded w-3/4 animate-pulse" />
                  <div className="h-5 bg-gray-200 rounded w-1/3 animate-pulse" />
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6">
              {featured.map((product, idx) => (
                <ProductCard key={product.id} product={product} index={idx} />
              ))}
            </div>
          )}

          <Button
            variant="outline"
            onClick={() => navigate({ page: 'catalog' })}
            className="w-full sm:hidden mt-6 border-primary text-primary hover:bg-primary hover:text-white"
          >
            Ver todos los productos
          </Button>
        </div>
      </section>

      {/* Category Highlight */}
      <section className="py-10 sm:py-16 bg-primary">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10 sm:mb-12">
            <span className="text-gold text-xs font-semibold tracking-[0.2em] uppercase">Explora</span>
            <h2 className="text-2xl sm:text-3xl font-bold text-white mt-1">Nuestras Categorías</h2>
          </div>

          <div className="grid sm:grid-cols-2 gap-6">
            {/* Beds */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <Card
                className="overflow-hidden cursor-pointer group border-0 hover:shadow-2xl transition-all duration-500"
                onClick={() => navigate({ page: 'catalog', filters: { category: 'camas' } })}
              >
                <div className="relative h-48 sm:h-64 bg-gradient-to-br from-navy-light to-navy overflow-hidden">
                  <img
                    src="/uploads/cama-queen-clasica.jpg"
                    alt="Camas Distribuidora Belén"
                    className="w-full h-full object-cover opacity-40 group-hover:opacity-50 group-hover:scale-105 transition-all duration-700"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement
                      target.style.display = 'none'
                    }}
                  />
                  <div className="absolute inset-0 flex flex-col items-center justify-center p-6">
                    <Bed className="h-10 w-10 text-gold mb-3" />
                    <h3 className="text-2xl font-bold text-white">Camas</h3>
                    <p className="text-white/70 text-sm mt-1">Diseño propio • Incluyen colchón</p>
                  </div>
                </div>
              </Card>
            </motion.div>

            {/* Mattresses */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
            >
              <Card
                className="overflow-hidden cursor-pointer group border-0 hover:shadow-2xl transition-all duration-500"
                onClick={() => navigate({ page: 'catalog', filters: { category: 'colchones' } })}
              >
                <div className="relative h-48 sm:h-64 bg-gradient-to-br from-gold to-gold-light overflow-hidden">
                  <img
                    src="/uploads/colchon-king.jpg"
                    alt="Colchones Apraiso"
                    className="w-full h-full object-cover opacity-40 group-hover:opacity-50 group-hover:scale-105 transition-all duration-700"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement
                      target.style.display = 'none'
                    }}
                  />
                  <div className="absolute inset-0 flex flex-col items-center justify-center p-6">
                    <Star className="h-10 w-10 text-white mb-3" />
                    <h3 className="text-2xl font-bold text-white">Colchones Apraiso</h3>
                    <p className="text-white/80 text-sm mt-1">Calidad premium • Todas las tallas</p>
                  </div>
                </div>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* About / CTA */}
      <section className="py-16 sm:py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <span className="text-gold text-xs font-semibold tracking-[0.2em] uppercase">Sobre nosotros</span>
          <h2 className="text-2xl sm:text-3xl font-bold text-foreground mt-1 mb-4">Distribuidora Belén</h2>
          <p className="text-muted-foreground leading-relaxed max-w-2xl mx-auto mb-4">
            Con más de una década de experiencia en el mercado de camas y colchones, en Distribuidora Belén nos dedicamos a ofrecer productos de la más alta calidad que transformen tu experiencia de descanso. Nuestras camas son diseñadas y fabricadas con los mejores materiales, y trabajamos exclusivamente con la reconocida marca Apraiso para ofrecer colchones que garantizan noches de sueño reparador.
          </p>
          <p className="text-muted-foreground leading-relaxed max-w-2xl mx-auto mb-8">
            Nuestro compromiso es brindarte no solo un producto excepcional, sino también una experiencia de compra personalizada y un servicio postventa que te respalde en cada momento. Visítanos y descubre por qué cientos de familias confían en nosotros para su descanso.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <a href="https://wa.me/?text=Hola%2C%20me%20interesa%20conocer%20más%20sobre%20sus%20productos" target="_blank" rel="noopener noreferrer">
              <Button size="lg" className="bg-[#25D366] hover:bg-[#20BD5A] text-white font-semibold px-8 h-12">
                Contáctanos por WhatsApp
              </Button>
            </a>
            <Button
              size="lg"
              variant="outline"
              className="border-primary text-primary hover:bg-primary hover:text-white font-semibold px-8 h-12"
              onClick={() => navigate({ page: 'catalog' })}
            >
              Explorar Productos
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
