'use client'

import { useState, useEffect } from 'react'
import { useStore } from '@/lib/store'
import { MapPin, Phone, Mail, Clock } from 'lucide-react'
import { Separator } from '@/components/ui/separator'

export default function Footer() {
  const { navigate } = useStore()
  const [settings, setSettings] = useState<Record<string, string>>({})

  useEffect(() => {
    fetch('/api/settings')
      .then(res => res.json())
      .then(data => setSettings(data))
      .catch(() => {})
  }, [])

  const phone = settings.phone || '+51 (01) 234-5678'
  const email = settings.email || 'ventas@distribuidorabelen.com'
  const address = settings.address || 'Av. Principal #123, Lima, Perú'
  const hours = settings.business_hours || 'Lun-Sáb: 9:00 - 19:00'

  return (
    <footer className="bg-primary text-white mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          {/* Brand */}
          <div className="sm:col-span-2 lg:col-span-1">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-gold flex items-center justify-center">
                <span className="text-white font-bold text-lg">B</span>
              </div>
              <div>
                <h3 className="font-bold text-lg">Distribuidora Belén</h3>
                <p className="text-xs text-gold tracking-widest font-semibold">PREMIUM</p>
              </div>
            </div>
            <p className="text-white/70 text-sm leading-relaxed">
              Tu descanso, nuestra pasión. Más de 10 años ofreciendo las mejores camas y colchones del mercado con la calidad y servicio que usted merece.
            </p>
          </div>

          {/* Links */}
          <div>
            <h4 className="font-semibold text-gold mb-4 text-sm uppercase tracking-wider">Navegación</h4>
            <ul className="space-y-2">
              {[
                { label: 'Inicio', page: 'home' },
                { label: 'Productos', page: 'catalog' },
                { label: 'Camas', page: 'catalog', filter: 'camas' },
                { label: 'Colchones', page: 'catalog', filter: 'colchones' },
              ].map((item) => (
                <li key={item.label}>
                  <button
                    onClick={() => navigate(item.filter ? { page: item.page, filters: { category: item.filter } } : { page: item.page })}
                    className="text-white/70 hover:text-gold transition-colors text-sm"
                  >
                    {item.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-semibold text-gold mb-4 text-sm uppercase tracking-wider">Contacto</h4>
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-sm text-white/70">
                <Phone className="h-4 w-4 text-gold flex-shrink-0" />
                <span>{phone}</span>
              </li>
              <li className="flex items-center gap-2 text-sm text-white/70">
                <Mail className="h-4 w-4 text-gold flex-shrink-0" />
                <span>{email}</span>
              </li>
              <li className="flex items-start gap-2 text-sm text-white/70">
                <MapPin className="h-4 w-4 text-gold flex-shrink-0 mt-0.5" />
                <span>{address}</span>
              </li>
              <li className="flex items-center gap-2 text-sm text-white/70">
                <Clock className="h-4 w-4 text-gold flex-shrink-0" />
                <span>{hours}</span>
              </li>
            </ul>
          </div>

          {/* Brands */}
          <div>
            <h4 className="font-semibold text-gold mb-4 text-sm uppercase tracking-wider">Marcas</h4>
            <div className="space-y-3">
              <div className="bg-white/10 rounded-lg p-3">
                <p className="font-semibold text-sm">Distribuidora Belén</p>
                <p className="text-xs text-white/60">Camas de diseño propio</p>
              </div>
              <div className="bg-white/10 rounded-lg p-3">
                <p className="font-semibold text-sm">Apraiso</p>
                <p className="text-xs text-white/60">Colchones de alta calidad</p>
              </div>
            </div>
          </div>
        </div>

        <Separator className="my-8 bg-white/10" />

        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-white/50">
            © {new Date().getFullYear()} Distribuidora Belén. Todos los derechos reservados.
          </p>
          <p className="text-xs text-white/50">
            Hecho con ❤️ para tu mejor descanso
          </p>
        </div>
      </div>
    </footer>
  )
}
