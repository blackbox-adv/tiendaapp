'use client'

import { useStore } from '@/lib/store'
import ProductGrid from './ProductGrid'

export default function CatalogPage() {
  const { route } = useStore()
  const filters = route.page === 'catalog' ? route.filters : undefined

  return (
    <div className="min-h-screen">
      {/* Page Header */}
      <div className="bg-primary py-8 sm:py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-2xl sm:text-3xl font-bold text-white">
            {filters?.category === 'camas' ? 'Nuestras Camas' :
             filters?.category === 'colchones' ? 'Colchones Apraiso' :
             'Todos los Productos'}
          </h1>
          <p className="text-white/60 mt-1 text-sm sm:text-base">
            {filters?.category === 'camas' 
              ? 'Camas de diseño propio con colchón Apraiso incluido'
              : filters?.category === 'colchones'
              ? 'Colchones de la reconocida marca Apraiso'
              : 'Explora nuestra colección completa de camas y colchones'}
          </p>
        </div>
      </div>

      <ProductGrid
        key={filters?.category || 'todos'}
        categoryFilter={filters?.category}
        searchQuery={filters?.search}
      />
    </div>
  )
}
