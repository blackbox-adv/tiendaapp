'use client'

import { useState, useEffect } from 'react'
import { useStore } from '@/lib/store'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Package, Tags, Star, TrendingUp, Eye, EyeOff } from 'lucide-react'
import { Button } from '@/components/ui/button'
import type { Product, Category } from '@/lib/types'
import AdminLayout from './AdminLayout'

export default function AdminDashboard() {
  const { navigate } = useStore()
  const [stats, setStats] = useState({ products: 0, categories: 0, featured: 0, active: 0 })
  const [recentProducts, setRecentProducts] = useState<Product[]>([])

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [prodRes, catRes] = await Promise.all([
          fetch('/api/products'),
          fetch('/api/categories'),
        ])
        const products: Product[] = await prodRes.json()
        const categories: Category[] = await catRes.json()

        setStats({
          products: products.length,
          categories: categories.length,
          featured: products.filter(p => p.isFeatured).length,
          active: products.filter(p => p.isActive).length,
        })

        setRecentProducts(products.slice(0, 5))
      } catch { /* ignore */ }
    }
    fetchData()
  }, [])

  const statCards = [
    { label: 'Total Productos', value: stats.products, icon: Package, color: 'text-primary' },
    { label: 'Categorías', value: stats.categories, icon: Tags, color: 'text-gold' },
    { label: 'Destacados', value: stats.featured, icon: Star, color: 'text-amber-500' },
    { label: 'Activos', value: stats.active, icon: TrendingUp, color: 'text-green-600' },
  ]

  return (
    <AdminLayout activePage="dashboard">
      <div className="space-y-6 animate-fadeIn">
        <div className="flex items-center justify-between">
          <h1 className="text-xl sm:text-2xl font-bold text-foreground">Dashboard</h1>
          <Button
            onClick={() => navigate({ page: 'admin-product-form' })}
            className="bg-primary hover:bg-primary/90 text-white"
          >
            + Nuevo Producto
          </Button>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
          {statCards.map((stat) => (
            <Card key={stat.label} className="border-0 shadow-sm">
              <CardContent className="p-4 sm:p-6">
                <div className="flex items-center justify-between mb-2">
                  <stat.icon className={`h-5 w-5 ${stat.color}`} />
                </div>
                <p className="text-2xl sm:text-3xl font-bold text-foreground">{stat.value}</p>
                <p className="text-xs text-muted-foreground mt-1">{stat.label}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Recent Products */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base font-semibold">Productos Recientes</CardTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate({ page: 'admin-products' })}
                className="text-primary text-xs"
              >
                Ver todos →
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentProducts.map((product) => (
                <div
                  key={product.id}
                  className="flex items-center gap-3 p-2 rounded-lg hover:bg-warm-gray transition-colors cursor-pointer"
                  onClick={() => navigate({ page: 'admin-product-form', productId: product.id })}
                >
                  <div className="w-10 h-10 rounded-lg bg-warm-gray overflow-hidden flex-shrink-0">
                    {product.images[0] && (
                      <img src={product.images[0].url} alt="" className="w-full h-full object-cover" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground truncate">{product.name}</p>
                    <p className="text-xs text-muted-foreground">{product.category?.name}</p>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className="text-sm font-semibold">S/ {product.price.toLocaleString('es-PE')}</p>
                    <div className="flex items-center gap-1 justify-end">
                      {product.isActive ? <Eye className="h-3 w-3 text-green-500" /> : <EyeOff className="h-3 w-3 text-red-400" />}
                      {product.isFeatured && <Star className="h-3 w-3 text-amber-500 fill-amber-500" />}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  )
}
