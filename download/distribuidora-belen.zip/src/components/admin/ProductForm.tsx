'use client'

import { useState, useEffect } from 'react'
import { useStore } from '@/lib/store'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Switch } from '@/components/ui/switch'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import { ArrowLeft, Save, Upload, X, Loader2 } from 'lucide-react'
import type { Product, Category } from '@/lib/types'
import AdminLayout from './AdminLayout'

export default function ProductForm() {
  const { route, navigate } = useStore()
  const editId = route.page === 'admin-product-form' ? route.productId : undefined

  const [loading, setLoading] = useState(false)
  const [saving, setSaving] = useState(false)
  const [categories, setCategories] = useState<Category[]>([])
  const [mattresses, setMattresses] = useState<Product[]>([])

  const [form, setForm] = useState({
    name: '',
    description: '',
    price: '',
    originalPrice: '',
    categoryId: '',
    dimensions: '',
    material: '',
    mattressId: '',
    isActive: true,
    isFeatured: false,
  })
  const [images, setImages] = useState<{ url: string; alt: string; isPrimary: boolean }[]>([])
  const [uploading, setUploading] = useState(false)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [catRes, mattRes] = await Promise.all([
          fetch('/api/categories'),
          fetch('/api/products?category=colchones'),
        ])
        setCategories(await catRes.json())
        setMattresses(await mattRes.json())
      } catch { /* ignore */ }

      if (editId) {
        setLoading(true)
        try {
          const res = await fetch(`/api/products/${editId}`)
          const data: Product = await res.json()
          setForm({
            name: data.name,
            description: data.description,
            price: data.price.toString(),
            originalPrice: data.originalPrice?.toString() || '',
            categoryId: data.categoryId,
            dimensions: data.dimensions || '',
            material: data.material || '',
            mattressId: data.mattressId || '',
            isActive: data.isActive,
            isFeatured: data.isFeatured,
          })
          setImages(data.images.map(img => ({ url: img.url, alt: img.alt || '', isPrimary: img.isPrimary })))
        } catch { /* ignore */ }
        setLoading(false)
      }
    }
    fetchData()
  }, [editId])

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files || files.length === 0) return

    setUploading(true)
    for (const file of Array.from(files)) {
      const fd = new FormData()
      fd.append('file', file)
      try {
        const res = await fetch('/api/upload', { method: 'POST', body: fd })
        const data = await res.json()
        if (data.url) {
          setImages(prev => [...prev, { url: data.url, alt: form.name, isPrimary: prev.length === 0 }])
        }
      } catch { /* ignore */ }
    }
    setUploading(false)
    e.target.value = ''
  }

  const removeImage = (idx: number) => {
    setImages(prev => prev.filter((_, i) => i !== idx))
  }

  const setPrimary = (idx: number) => {
    setImages(prev => prev.map((img, i) => ({ ...img, isPrimary: i === idx })))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSaving(true)

    try {
      const body = {
        ...form,
        price: parseFloat(form.price),
        originalPrice: form.originalPrice ? parseFloat(form.originalPrice) : null,
        images,
      }

      const url = editId ? `/api/products/${editId}` : '/api/products'
      const method = editId ? 'PUT' : 'POST'

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      })

      if (res.ok) {
        navigate({ page: 'admin-products' })
      }
    } catch { /* ignore */ }
    setSaving(false)
  }

  if (loading) {
    return (
      <AdminLayout activePage="products">
        <div className="flex items-center justify-center py-16">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      </AdminLayout>
    )
  }

  return (
    <AdminLayout activePage="products">
      <div className="space-y-4 animate-fadeIn max-w-3xl">
        {/* Header */}
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate({ page: 'admin-products' })}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-bold">{editId ? 'Editar Producto' : 'Nuevo Producto'}</h1>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Info */}
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-4">
              <CardTitle className="text-base">Información Básica</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Nombre del Producto *</Label>
                <Input id="name" value={form.name} onChange={(e) => setForm(f => ({ ...f, name: e.target.value }))} required />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Descripción *</Label>
                <Textarea id="description" value={form.description} onChange={(e) => setForm(f => ({ ...f, description: e.target.value }))} rows={4} required />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="category">Categoría *</Label>
                  <Select value={form.categoryId} onValueChange={(v) => setForm(f => ({ ...f, categoryId: v }))}>
                    <SelectTrigger><SelectValue placeholder="Seleccionar" /></SelectTrigger>
                    <SelectContent>
                      {categories.map(cat => (
                        <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {form.categoryId && categories.find(c => c.id === form.categoryId)?.slug === 'camas' && (
                  <div className="space-y-2">
                    <Label>Colchón Incluido</Label>
                    <Select value={form.mattressId} onValueChange={(v) => setForm(f => ({ ...f, mattressId: v }))}>
                      <SelectTrigger><SelectValue placeholder="Seleccionar colchón" /></SelectTrigger>
                      <SelectContent>
                        {mattresses.map(m => (
                          <SelectItem key={m.id} value={m.id}>{m.name} - S/ {m.price.toLocaleString('es-PE')}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Pricing */}
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-4">
              <CardTitle className="text-base">Precios</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="price">Precio *</Label>
                <Input id="price" type="number" step="0.01" value={form.price} onChange={(e) => setForm(f => ({ ...f, price: e.target.value }))} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="originalPrice">Precio Anterior (antes de descuento)</Label>
                <Input id="originalPrice" type="number" step="0.01" value={form.originalPrice} onChange={(e) => setForm(f => ({ ...f, originalPrice: e.target.value }))} />
              </div>
            </CardContent>
          </Card>

          {/* Specs */}
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-4">
              <CardTitle className="text-base">Especificaciones</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="dimensions">Dimensiones</Label>
                <Input id="dimensions" placeholder="Ej: 200 x 160 cm" value={form.dimensions} onChange={(e) => setForm(f => ({ ...f, dimensions: e.target.value }))} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="material">Material</Label>
                <Input id="material" placeholder="Ej: Madera de pino" value={form.material} onChange={(e) => setForm(f => ({ ...f, material: e.target.value }))} />
              </div>
            </CardContent>
          </Card>

          {/* Images */}
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-4">
              <CardTitle className="text-base">Imágenes</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-wrap gap-3">
                {images.map((img, idx) => (
                  <div key={idx} className="relative group w-24 h-24 rounded-lg overflow-hidden border-2 border-border">
                    <img src={img.url} alt="" className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-1">
                      <button
                        type="button"
                        onClick={() => setPrimary(idx)}
                        className="text-[10px] px-1.5 py-0.5 bg-gold text-white rounded"
                      >
                        {img.isPrimary ? '★ Principal' : 'Principal'}
                      </button>
                      <button
                        type="button"
                        onClick={() => removeImage(idx)}
                        className="text-[10px] px-1.5 py-0.5 bg-red-500 text-white rounded"
                      >
                        ✕
                      </button>
                    </div>
                    {img.isPrimary && (
                      <div className="absolute top-1 left-1">
                        <span className="text-[9px] px-1 py-0.5 bg-gold text-white rounded font-semibold">★</span>
                      </div>
                    )}
                  </div>
                ))}
                <label className={`w-24 h-24 rounded-lg border-2 border-dashed border-border flex flex-col items-center justify-center cursor-pointer hover:border-primary hover:bg-warm-gray transition-colors ${uploading ? 'opacity-50 pointer-events-none' : ''}`}>
                  {uploading ? (
                    <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                  ) : (
                    <>
                      <Upload className="h-5 w-5 text-muted-foreground" />
                      <span className="text-[10px] text-muted-foreground mt-1">Subir</span>
                    </>
                  )}
                  <input type="file" accept="image/*" multiple className="hidden" onChange={handleUpload} />
                </label>
              </div>
            </CardContent>
          </Card>

          {/* Toggles */}
          <Card className="border-0 shadow-sm">
            <CardContent className="py-4 flex flex-col sm:flex-row gap-4">
              <div className="flex items-center justify-between flex-1">
                <Label>Producto Activo</Label>
                <Switch checked={form.isActive} onCheckedChange={(v) => setForm(f => ({ ...f, isActive: v }))} />
              </div>
              <div className="flex items-center justify-between flex-1">
                <Label>Destacado</Label>
                <Switch checked={form.isFeatured} onCheckedChange={(v) => setForm(f => ({ ...f, isFeatured: v }))} />
              </div>
            </CardContent>
          </Card>

          {/* Submit */}
          <div className="flex gap-3">
            <Button type="submit" className="bg-primary hover:bg-primary/90 text-white" disabled={saving}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <Save className="h-4 w-4 mr-1" />}
              {saving ? 'Guardando...' : 'Guardar Producto'}
            </Button>
            <Button type="button" variant="outline" onClick={() => navigate({ page: 'admin-products' })}>
              Cancelar
            </Button>
          </div>
        </form>
      </div>
    </AdminLayout>
  )
}
