'use client'

import { useState, useEffect } from 'react'
import { useStore } from '@/lib/store'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'
import { Plus, Pencil, Trash2, Save, Package } from 'lucide-react'
import type { Category } from '@/lib/types'
import AdminLayout from './AdminLayout'

export default function CategoryList() {
  const [categories, setCategories] = useState<Category[]>([])
  const [editing, setEditing] = useState<Category | null>(null)
  const [isNew, setIsNew] = useState(false)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [form, setForm] = useState({ name: '', slug: '', order: 0 })

  useEffect(() => {
    let cancelled = false
    fetch('/api/categories')
      .then(res => res.json())
      .then(data => { if (!cancelled) setCategories(data) })
      .catch(() => {})
    return () => { cancelled = true }
  }, [])

  const fetchCategories = async () => {
    const res = await fetch('/api/categories')
    setCategories(await res.json())
  }

  const handleSave = async () => {
    if (!form.name.trim()) return
    try {
      if (isNew) {
        await fetch('/api/categories', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name: form.name, slug: form.slug || form.name.toLowerCase().replace(/\s+/g, '-'), order: form.order }),
        })
      } else if (editing) {
        await fetch(`/api/categories/${editing.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name: form.name, slug: form.slug, order: form.order }),
        })
      }
      fetchCategories()
      setEditing(null)
      setIsNew(false)
    } catch { /* ignore */ }
  }

  const handleDelete = async () => {
    if (!deleteId) return
    try {
      const res = await fetch(`/api/categories/${deleteId}`, { method: 'DELETE' })
      const data = await res.json()
      if (!res.ok) {
        alert(data.error || 'Error al eliminar')
      } else {
        fetchCategories()
      }
      setDeleteId(null)
    } catch { /* ignore */ }
  }

  const openEdit = (cat: Category) => {
    setEditing(cat)
    setForm({ name: cat.name, slug: cat.slug, order: cat.order })
    setIsNew(false)
  }

  const openNew = () => {
    setEditing(null)
    setForm({ name: '', slug: '', order: categories.length })
    setIsNew(true)
  }

  return (
    <AdminLayout activePage="categories">
      <div className="space-y-4 animate-fadeIn max-w-2xl">
        <div className="flex items-center justify-between">
          <h1 className="text-xl sm:text-2xl font-bold">Categorías</h1>
          <Button onClick={openNew} className="bg-primary hover:bg-primary/90 text-white">
            <Plus className="h-4 w-4 mr-1" /> Nueva
          </Button>
        </div>

        <div className="space-y-3">
          {categories.map((cat) => (
            <Card key={cat.id} className="border-0 shadow-sm">
              <CardContent className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-warm-gray flex items-center justify-center">
                    <Package className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-semibold">{cat.name}</p>
                    <p className="text-xs text-muted-foreground">Slug: {cat.slug} • {cat._count?.products || 0} productos</p>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(cat)}>
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => setDeleteId(cat.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
          {categories.length === 0 && (
            <p className="text-center text-muted-foreground py-8">No hay categorías</p>
          )}
        </div>

        {/* Edit/New Dialog */}
        <Dialog open={isNew || !!editing} onOpenChange={() => { setEditing(null); setIsNew(false) }}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{isNew ? 'Nueva Categoría' : 'Editar Categoría'}</DialogTitle>
              <DialogDescription>{isNew ? 'Crea una nueva categoría para tus productos' : 'Modifica los datos de la categoría'}</DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-2">
              <div className="space-y-2">
                <Label>Nombre *</Label>
                <Input value={form.name} onChange={(e) => setForm(f => ({ ...f, name: e.target.value }))} />
              </div>
              <div className="space-y-2">
                <Label>Slug</Label>
                <Input value={form.slug} onChange={(e) => setForm(f => ({ ...f, slug: e.target.value }))} />
              </div>
              <div className="space-y-2">
                <Label>Orden</Label>
                <Input type="number" value={form.order} onChange={(e) => setForm(f => ({ ...f, order: parseInt(e.target.value) || 0 }))} />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => { setEditing(null); setIsNew(false) }}>Cancelar</Button>
              <Button onClick={handleSave} className="bg-primary text-white"><Save className="h-4 w-4 mr-1" /> Guardar</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Delete Dialog */}
        <Dialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Eliminar Categoría</DialogTitle>
              <DialogDescription>¿Estás seguro? No se puede eliminar si tiene productos asociados.</DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button variant="outline" onClick={() => setDeleteId(null)}>Cancelar</Button>
              <Button variant="destructive" onClick={handleDelete}>Eliminar</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  )
}
