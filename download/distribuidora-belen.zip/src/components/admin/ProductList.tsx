'use client'

import { useState, useEffect } from 'react'
import { useStore } from '@/lib/store'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from '@/components/ui/dialog'
import { Search, Plus, Pencil, Trash2, Star, Eye, EyeOff } from 'lucide-react'
import type { Product } from '@/lib/types'
import AdminLayout from './AdminLayout'

export default function ProductList() {
  const { navigate } = useStore()
  const [products, setProducts] = useState<Product[]>([])
  const [search, setSearch] = useState('')
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let cancelled = false
    const doFetch = async () => {
      const res = await fetch('/api/products' + (search ? `?search=${search}` : ''))
      if (!cancelled) {
        const data = await res.json()
        setProducts(data)
        setLoading(false)
      }
    }
    doFetch().catch(() => { if (!cancelled) { setProducts([]); setLoading(false) } })
    return () => { cancelled = true }
  }, [search])

  const handleDelete = async () => {
    if (!deleteId) return
    try {
      await fetch(`/api/products/${deleteId}`, { method: 'DELETE' })
      setProducts(prev => prev.filter(p => p.id !== deleteId))
      setDeleteId(null)
    } catch { /* ignore */ }
  }

  const toggleFeatured = async (product: Product) => {
    try {
      await fetch(`/api/products/${product.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...product,
          isFeatured: !product.isFeatured,
          categoryId: product.categoryId,
          price: product.price,
          images: [],
        }),
      })
      const res2 = await fetch('/api/products' + (search ? `?search=${search}` : ''))
      const data2 = await res2.json()
      setProducts(data2)
    } catch { /* ignore */ }
  }

  const toggleActive = async (product: Product) => {
    try {
      await fetch(`/api/products/${product.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...product,
          isActive: !product.isActive,
          categoryId: product.categoryId,
          price: product.price,
          images: [],
        }),
      })
      const res2 = await fetch('/api/products' + (search ? `?search=${search}` : ''))
      const data2 = await res2.json()
      setProducts(data2)
    } catch { /* ignore */ }
  }

  return (
    <AdminLayout activePage="products">
      <div className="space-y-4 animate-fadeIn">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <h1 className="text-xl sm:text-2xl font-bold text-foreground">Productos</h1>
          <Button
            onClick={() => navigate({ page: 'admin-product-form' })}
            className="bg-primary hover:bg-primary/90 text-white"
          >
            <Plus className="h-4 w-4 mr-1" /> Nuevo Producto
          </Button>
        </div>

        {/* Search */}
        <div className="relative max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar productos..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10"
          />
        </div>

        {/* Table */}
        <Card className="border-0 shadow-sm overflow-hidden">
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-warm-gray/50">
                    <TableHead className="w-12">Img</TableHead>
                    <TableHead>Producto</TableHead>
                    <TableHead className="hidden sm:table-cell">Categoría</TableHead>
                    <TableHead>Precio</TableHead>
                    <TableHead className="hidden md:table-cell">Estado</TableHead>
                    <TableHead className="w-32 text-right">Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {products.map((product) => (
                    <TableRow key={product.id} className="cursor-pointer hover:bg-warm-gray/30" onClick={() => navigate({ page: 'admin-product-form', productId: product.id })}>
                      <TableCell>
                        <div className="w-10 h-10 rounded-lg bg-warm-gray overflow-hidden">
                          {product.images[0] && (
                            <img src={product.images[0].url} alt="" className="w-full h-full object-cover" />
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <p className="font-medium text-sm">{product.name}</p>
                        <p className="text-xs text-muted-foreground sm:hidden">{product.category?.name}</p>
                      </TableCell>
                      <TableCell className="hidden sm:table-cell">
                        <Badge variant="secondary" className="text-xs">{product.category?.name}</Badge>
                      </TableCell>
                      <TableCell>
                        <p className="font-semibold text-sm">S/ {product.price.toLocaleString('es-PE')}</p>
                        {product.originalPrice && (
                          <p className="text-xs text-muted-foreground line-through">S/ {product.originalPrice.toLocaleString('es-PE')}</p>
                        )}
                      </TableCell>
                      <TableCell className="hidden md:table-cell">
                        <div className="flex items-center gap-1">
                          <Badge variant={product.isActive ? 'default' : 'secondary'} className={`text-[10px] ${product.isActive ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-600'}`}>
                            {product.isActive ? 'Activo' : 'Inactivo'}
                          </Badge>
                          {product.isFeatured && (
                            <Star className="h-3.5 w-3.5 text-amber-500 fill-amber-500" />
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center justify-end gap-1" onClick={(e) => e.stopPropagation()}>
                          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => toggleFeatured(product)} title="Destacado">
                            <Star className={`h-4 w-4 ${product.isFeatured ? 'text-amber-500 fill-amber-500' : 'text-muted-foreground'}`} />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => toggleActive(product)} title="Activar/Desactivar">
                            {product.isActive ? <Eye className="h-4 w-4 text-green-600" /> : <EyeOff className="h-4 w-4 text-red-400" />}
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => setDeleteId(product.id)} title="Eliminar">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                  {products.length === 0 && !loading && (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                        No se encontraron productos
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Delete Dialog */}
      <Dialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Eliminar Producto</DialogTitle>
            <DialogDescription>¿Estás seguro de que deseas eliminar este producto? Esta acción no se puede deshacer.</DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteId(null)}>Cancelar</Button>
            <Button variant="destructive" onClick={handleDelete}>Eliminar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AdminLayout>
  )
}
