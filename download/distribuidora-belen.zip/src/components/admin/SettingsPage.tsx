'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Switch } from '@/components/ui/switch'
import { Save, Loader2, Phone, MessageCircle, Mail, MapPin, Clock, Globe } from 'lucide-react'
import { toast } from 'sonner'
import AdminLayout from './AdminLayout'

interface SiteSettings {
  whatsapp_number: string
  phone: string
  email: string
  address: string
  business_hours: string
  whatsapp_message: string
  currency_symbol: string
  currency_code: string
  show_whatsapp_float: string
}

const defaultSettings: SiteSettings = {
  whatsapp_number: '',
  phone: '',
  email: '',
  address: '',
  business_hours: '',
  whatsapp_message: 'Hola, estoy interesado/a en {product} de Distribuidora Belén',
  currency_symbol: 'S/',
  currency_code: 'PEN',
  show_whatsapp_float: 'true',
}

export default function SettingsPage() {
  const [settings, setSettings] = useState<SiteSettings>(defaultSettings)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    fetch('/api/settings')
      .then(res => res.json())
      .then(data => {
        setSettings({ ...defaultSettings, ...data })
        setLoading(false)
      })
      .catch(() => setLoading(false))
  }, [])

  const handleSave = async () => {
    setSaving(true)
    try {
      const res = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings),
      })
      if (res.ok) {
        toast.success('Configuración guardada exitosamente')
      } else {
        toast.error('Error al guardar la configuración')
      }
    } catch {
      toast.error('Error de conexión')
    }
    setSaving(false)
  }

  if (loading) {
    return (
      <AdminLayout activePage="settings">
        <div className="flex items-center justify-center py-16">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      </AdminLayout>
    )
  }

  return (
    <AdminLayout activePage="settings">
      <div className="space-y-6 animate-fadeIn max-w-3xl">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-foreground">Configuración del Sitio</h1>
            <p className="text-sm text-muted-foreground mt-1">Administra los datos de contacto y preferencias de la tienda</p>
          </div>
          <Button onClick={handleSave} className="bg-primary hover:bg-primary/90 text-white" disabled={saving}>
            {saving ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <Save className="h-4 w-4 mr-1" />}
            {saving ? 'Guardando...' : 'Guardar'}
          </Button>
        </div>

        {/* WhatsApp */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-4">
            <CardTitle className="text-base flex items-center gap-2">
              <MessageCircle className="h-5 w-5 text-green-600" />
              WhatsApp
            </CardTitle>
            <CardDescription>Configuración de contacto por WhatsApp</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="whatsapp_number">Número de WhatsApp *</Label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="whatsapp_number"
                  placeholder="51999999999 (sin + ni espacios)"
                  value={settings.whatsapp_number}
                  onChange={(e) => setSettings(s => ({ ...s, whatsapp_number: e.target.value }))}
                  className="pl-10"
                />
              </div>
              <p className="text-xs text-muted-foreground">Incluye el código de país sin el signo +. Ej: 51999999999</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="whatsapp_message">Mensaje predeterminado</Label>
              <Input
                id="whatsapp_message"
                placeholder="Hola, estoy interesado/a en..."
                value={settings.whatsapp_message}
                onChange={(e) => setSettings(s => ({ ...s, whatsapp_message: e.target.value }))}
              />
              <p className="text-xs text-muted-foreground">Usa {"{product}"} como marcador para el nombre del producto</p>
            </div>

            <div className="flex items-center justify-between py-2">
              <div>
                <Label>Botón flotante de WhatsApp</Label>
                <p className="text-xs text-muted-foreground">Mostrar botón flotante en toda la tienda</p>
              </div>
              <Switch
                checked={settings.show_whatsapp_float === 'true'}
                onCheckedChange={(v) => setSettings(s => ({ ...s, show_whatsapp_float: v ? 'true' : 'false' }))}
              />
            </div>
          </CardContent>
        </Card>

        {/* Contact Info */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-4">
            <CardTitle className="text-base flex items-center gap-2">
              <Phone className="h-5 w-5 text-primary" />
              Información de Contacto
            </CardTitle>
            <CardDescription>Datos que se muestran en el pie de página</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="phone">Teléfono fijo</Label>
                <Input
                  id="phone"
                  placeholder="+51 (01) 234-5678"
                  value={settings.phone}
                  onChange={(e) => setSettings(s => ({ ...s, phone: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Correo electrónico</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="email"
                    type="email"
                    placeholder="ventas@empresa.com"
                    value={settings.email}
                    onChange={(e) => setSettings(s => ({ ...s, email: e.target.value }))}
                    className="pl-10"
                  />
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="address">Dirección</Label>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="address"
                  placeholder="Av. Principal #123, Lima, Perú"
                  value={settings.address}
                  onChange={(e) => setSettings(s => ({ ...s, address: e.target.value }))}
                  className="pl-10"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="business_hours">Horario de atención</Label>
              <div className="relative">
                <Clock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="business_hours"
                  placeholder="Lun-Sáb: 9:00 - 19:00"
                  value={settings.business_hours}
                  onChange={(e) => setSettings(s => ({ ...s, business_hours: e.target.value }))}
                  className="pl-10"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Currency */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-4">
            <CardTitle className="text-base flex items-center gap-2">
              <Globe className="h-5 w-5 text-gold" />
              Moneda
            </CardTitle>
            <CardDescription>Configuración de moneda para mostrar precios</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="currency_symbol">Símbolo de moneda</Label>
                <Input
                  id="currency_symbol"
                  placeholder="S/"
                  value={settings.currency_symbol}
                  onChange={(e) => setSettings(s => ({ ...s, currency_symbol: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="currency_code">Código de moneda (ISO)</Label>
                <Input
                  id="currency_code"
                  placeholder="PEN"
                  value={settings.currency_code}
                  onChange={(e) => setSettings(s => ({ ...s, currency_code: e.target.value }))}
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Save Button */}
        <div className="flex justify-end pt-2">
          <Button onClick={handleSave} className="bg-primary hover:bg-primary/90 text-white px-8" disabled={saving}>
            {saving ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <Save className="h-4 w-4 mr-1" />}
            {saving ? 'Guardando...' : 'Guardar Cambios'}
          </Button>
        </div>
      </div>
    </AdminLayout>
  )
}
