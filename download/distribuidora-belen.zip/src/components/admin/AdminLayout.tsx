'use client'

import { useStore } from '@/lib/store'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import {
  LayoutDashboard, Package, Tags, LogOut, Home, ArrowLeft, Plus, BarChart3, TrendingUp, Settings
} from 'lucide-react'

interface AdminLayoutProps {
  children: React.ReactNode
  activePage?: string
}

export default function AdminLayout({ children, activePage = 'dashboard' }: AdminLayoutProps) {
  const { navigate, admin } = useStore()

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, page: 'admin' as const },
    { id: 'products', label: 'Productos', icon: Package, page: 'admin-products' as const },
    { id: 'categories', label: 'Categorías', icon: Tags, page: 'admin-categories' as const },
    { id: 'settings', label: 'Configuración', icon: Settings, page: 'admin-settings' as const },
  ]

  return (
    <div className="min-h-screen bg-warm-gray">
      {/* Admin Header */}
      <header className="bg-primary text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-14 sm:h-16">
            <div className="flex items-center gap-3">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => navigate({ page: 'home' })}
                className="text-white/70 hover:text-white hover:bg-white/10"
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <Separator orientation="vertical" className="h-6 bg-white/20" />
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-full bg-gold flex items-center justify-center">
                  <span className="text-white font-bold text-sm">B</span>
                </div>
                <span className="font-semibold text-sm hidden sm:inline">Admin Belén</span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-white/60 hidden sm:inline">{admin.adminName}</span>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => admin.logout()}
                className="text-white/70 hover:text-white hover:bg-white/10"
              >
                <LogOut className="h-4 w-4 sm:mr-1" />
                <span className="hidden sm:inline text-xs">Salir</span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-6">
        <div className="flex flex-col sm:flex-row gap-4 sm:gap-6">
          {/* Sidebar */}
          <aside className="w-full sm:w-56 flex-shrink-0">
            <nav className="flex sm:flex-col gap-1 overflow-x-auto pb-2 sm:pb-0">
              {menuItems.map((item) => (
                <Button
                  key={item.id}
                  variant={activePage === item.id ? 'secondary' : 'ghost'}
                  onClick={() => navigate({ page: item.page })}
                  className={`justify-start gap-2 w-full whitespace-nowrap ${
                    activePage === item.id
                      ? 'bg-white text-primary font-semibold shadow-sm'
                      : 'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  <item.icon className="h-4 w-4" />
                  {item.label}
                </Button>
              ))}
            </nav>
          </aside>

          {/* Content */}
          <main className="flex-1 min-w-0">
            {children}
          </main>
        </div>
      </div>
    </div>
  )
}
