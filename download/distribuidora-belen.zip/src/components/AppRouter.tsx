'use client'

import { useStore } from '@/lib/store'
import Header from '@/components/store/Header'
import Footer from '@/components/store/Footer'
import WhatsAppFloat from '@/components/store/WhatsAppFloat'
import HomePage from '@/components/store/HomePage'
import CatalogPage from '@/components/store/CatalogPage'
import ProductDetail from '@/components/store/ProductDetail'
import AdminLogin from '@/components/admin/AdminLogin'
import DashboardHome from '@/components/admin/DashboardHome'
import ProductList from '@/components/admin/ProductList'
import ProductForm from '@/components/admin/ProductForm'
import CategoryList from '@/components/admin/CategoryList'
import SettingsPage from '@/components/admin/SettingsPage'
import { Toaster } from '@/components/ui/sonner'

export default function AppRouter() {
  const { route } = useStore()

  const isAdmin = route.page === 'admin' || route.page === 'admin-products' || route.page === 'admin-product-form' || route.page === 'admin-categories' || route.page === 'admin-settings'

  return (
    <div className="min-h-screen flex flex-col">
      {!isAdmin && <Header />}
      
      <main className="flex-1">
        {route.page === 'home' && <HomePage />}
        {route.page === 'catalog' && <CatalogPage />}
        {route.page === 'product' && <ProductDetail />}
        {route.page === 'admin-login' && <AdminLogin />}
        {route.page === 'admin' && <DashboardHome />}
        {route.page === 'admin-products' && <ProductList />}
        {route.page === 'admin-product-form' && <ProductForm />}
        {route.page === 'admin-categories' && <CategoryList />}
        {route.page === 'admin-settings' && <SettingsPage />}
      </main>

      {!isAdmin && <Footer />}
      {!isAdmin && <WhatsAppFloat />}
      <Toaster position="top-right" richColors />
    </div>
  )
}
